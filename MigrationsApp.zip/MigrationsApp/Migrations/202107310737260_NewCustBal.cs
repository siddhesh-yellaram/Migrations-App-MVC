﻿namespace MigrationsApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NewCustBal : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Customers", "Balance", c => c.Int());
        }
        
        public override void Down()
        {
        }
    }
}
