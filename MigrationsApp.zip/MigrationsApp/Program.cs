﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MigrationsApp.Model;

namespace MigrationsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c2 = new Customer { Id = 7, Name = "Rachel", Location = "Tower" , Balance = 5000, Type = "Deposit" };
            AurionProDBContext db = new AurionProDBContext();
            db.Customers.Add(c2);
            db.SaveChanges();
        }
    }
}
